<?php

session_start();

$db = mysqli_connect('localhost', 'root', 'root', 'projektas') or die(mysqli_error($db));

if ("POST" == $_SERVER["REQUEST_METHOD"]) {
  if(isset($_POST["username"]) && isset($_POST["email"]) && isset($_POST["message"])){
    
    if (empty($_POST) == false) {
    $errors = array();
    $username = strip_tags($_POST["username"]);
    $email = strip_tags($_POST["email"]);
    $message = strip_tags($_POST["message"]);

    if (empty($username) == true || empty($email) == true || empty($message) == true) {
      $errors[] = "<p style=\"font-color:white; font-size: 25px;\" align=\"center\">Įveskite vardą, el. paštą ir žinutę!<p>";
    } else {
      if (ctype_alnum($username) == true) {
        $errors[] = "<p style=\"font-color:white; font-size: 25px;\" align=\"center\">Varde galima naudoti tik raides!</p>";
      }
      if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
        $errors[] = "<p style=\"font-color:white; font-size: 25px;\" align=\"center\"> Neteisingas el. pašto adresas!</p>";
      }
    }

    if (empty($errors) == true) {
      mail("drungelike@gmail.com", "Kontaktai", $message, "Nuo:" . $email);
      $_SESSION["msgsent"] = true;
    }

    if (empty($username) == false && empty($email) == false && empty($message) == false && $_SESSION["msgsent"] == true){
      $sql = "INSERT INTO forma(username, email, message)
               VALUES ('{$username}','{$email}','{$message}')";
      mysqli_query($db, $sql) or die(mysqli_error($db));
    }
    }
    mysqli_close($db);
  }

  $_SESSION["errors"] = serialize($errors);

  header("Location: index.php#kontaktai");
  exit;
}
?><!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-type" content="text/php; charset=UTF-8" />

  <link href="https://fonts.googleapis.com/css?family=Baloo+Bhaijaan|Athiti|Lekton|Open+Sans" rel="stylesheet">

  	<!-- ikonos psl apacioj -->
  <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">

    <!-- slaideris -->
  <link rel="stylesheet" href="css/feature-carousel.css" charset="utf-8" />
  <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
    
    <!-- mano stilius -->
  <script type="text/javascript" src="script.js"></script>
  <link rel="stylesheet" type="text/css" href="style.css">

  <title>Outside the box</title>

  <script type="text/javascript">
    $(document).ready(function() {
      var carousel = $("#carousel").featureCarousel({});
      $("#but_prev").click(function () {carousel.prev();});
    $("#but_pause").click(function () {carousel.pause();});
    $("#but_start").click(function () {carousel.start();});
    $("#but_next").click(function () {carousel.next();});});
  </script>
</head>

<body>
        <!-- PRADINIS -->
  <section id="home">
    <header id="top">

      <img src="img/back_model.png">

      <nav class="navig">
    
    
        <a id="burger-nav"></a><!-- burger meniu -->

        <img src="img/agency.png">

        <ul class="listas">
        	<a href="#kontaktai"><li>KONTAKTAI</li></a>
        	<a href="#komanda"><li>KOMANDA</li></a>
        	<a href="#procesas"><li>KŪRIMO PROCESAS</li></a>
        	<a href="#paslaugos"><li>PASLAUGOS</li></a>
        	<a href="#apie_mus"><li>APIE MUS</li></a>
        	<a href="#home"><li>PRADINIS</li></a>
        </ul>

      </nav>
    </header>
  </section>

        <!-- A PIE MUS -->
  <section id="apie_mus">
    <div class="centruoti">
      <div class="aprasymas">
        <h1>Apie mus</h1>
        <p>Ar Jūsų internetinis puslapis pasiruošęs pritraukti vartotojų dėmesį? Jei taip nėra, tai laikas rimtai pagalvoti apie interneto plėtros galimybes. Mes sukursime originalų dizainą ir suprogramuosime tinklapį pagal JŪSŲ poreikius.</p>
      </div>
      <img src="img/kompas.png">
    </div>
    <div class="clearfix"></div>
  </section>


        <!-- PASLAUGOS -->
  <section id="paslaugos">
    <!-- trys stulpeliai -->
    <div class="musu_pasl">
      <div class="center-outer">
        <div class="center-inner">
          <div class="bubbles">
            <h1>Mūsų paslaugos</h1>
          </div>
        </div>
      </div>
    </div>
    <div class="visi_stulpeliai">
      <div class="stulp">
        <div class="stulpelis">
          <img src="img/creative_icon.png">
          <h1>Kūrybiškas darbas</h1>
          <p>Mes nuolat sekame vartotojų lūkesčius ir dirbdami su Jumis galime sukurti optimaliausią sprendimą Jūsų verslui. Internetinių svetainių kūrimas – tai tas kuo mes gyvename!</p>
        </div>
        <div class="stulpelis">
          <img src="img/best_icon.png">
          <h1>Atliekame geriausiai</h1>
          <p>Visoms mūsų paslaugoms yra ilgalaikė garantija. Bendradarbiaujame su laisvai samdomais programuotojais ir dizaineriais, tai leidžia užtikrinti konkurencingą kainą.</p>
        </div>
        <div class="stulpelis">
          <img src="img/company_icon.png">
          <h1>Geriausia įmonė</h1>
          <p>Visos svetainės kuriamos vadovaujantis teisės aktų ir savivaldybių rekomendacijų. Visiems savo klientams teikiame nemokamą pagalbą interneto svetainės klausimais.</p>
        </div>
      </div>
      <div class="stulp">
        <div class="stulpelis">
          <img src="img/idea_icon.png">
          <h1>Puiki idėja</h1>
          <p>Mažos kainos yra mūsų verslo idėjos pagrindas. Mes nuolatos stengiamės viską atlikti ekonomiškai. Sukursime internetinį puslapį su visame pasaulyje gerai žinomomis turinio valdymo sistemomis.</p>
        </div>
        <div class="stulpelis">
          <img src="img/proff_icon.png">
          <h1>Profesionalumas</h1>
          <p>Gražus profesionalus dizainas, jokios reklamos. Griežtai laikomės terminų, skubiai padedame atlikti užduotis. Suteiksime pinigų gražinimo garantiją, jei Jums mūsų darbas netiks Jus už jį galėsite nemokėti.</p>
        </div>
        <div class="stulpelis">
          <img src="img/great_icon.png">
          <h1>Kokybiškos paslaugos</h1>
          <p>Klaidas, kurias daro pradedančios įmonės, mes jau padarėme, todėl galime pasiūlyti kokybišką paslaugą. Atidžiai išklausysime Jūsų norus, išanalizuosime Jūsų konkurentus ir pateiksime tinkamiausius sprendimus.</p>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
  </section>

        <!-- PROCESAS -->
  <section id="procesas">
    <div class="lefty">
      <h1>Kūrimo procesas</h1>
      <p>Atliekama įmonės, konkurentų ir potencialių klientų analizė. Sukuriamas prototipas, pateikiama dizaino koncepcija. Toliau - programavimas bei SEO optimizavimas. Paskutinis etapas - testavimas, po kurio tinklalapis pateikiamas klientui. Proceso galutinis tikslas - laimingas klientas.</p>
    </div>
    <div class="righty">
      <img class="rotate-scale-down-ver" src="img/idea.png">
      <img class="rotate-scale-down-ver" src="img/design.png">
      <img class="rotate-scale-down-ver" src="img/happy.png">
    </div>
  </section>

        <!-- KONTAKTAI -->
  <section id="kontaktai">
    <h1><span>Susisiekite</span></h1>
    <?php
    if (isset($_SESSION["msgsent"]) == true) {
      echo "<p style=\"font-color:white; font-size: 25px;\" align=\"center\">Žinutė išsiųsta!</p><br>";
      $_SESSION["msgsent"] = false;
    }
    if (isset($_SESSION["errors"])) {
      $errors = unserialize($_SESSION["errors"]);
    }
    if (empty($errors) == false) { 
      echo "<ul>";
      foreach ($errors as $error) {
        echo "<li>", $error, "<li>";
      }
      echo "</ul>";
    }
    session_destroy();
    ?>
    <div class="vidurys">
      <form action="" method="POST">
        <p><input type="text" name="username" id="vardas" placeholder="Vardas"></p><br>
        <p><input type="text" name="email" id="pastas"  placeholder="El. paštas"></p><br>
        <p><textarea name="message" id="zinute" placeholder="Jūsų žinutė" rows="4" cols="50"></textarea></p><br>
        <input id="submit" type="submit" value="Siųsti">
      </form>

        <!-- IKONOS -->
      <div class="ikonos">
        <a class="social" href="https://www.facebook.com/" target="_blank">
          <div class="front">
            <i class="fa fa-facebook"></i>
          </div>
          <div class="back">
            <i class="fa fa-facebook"></i>
          </div>
        </a>
        <a class="social social-twitter" href="https://twitter.com/" target="_blank">
          <div class="front">
            <i class="fa fa-twitter"></i>
          </div>
          <div class="back">
            <i class="fa fa-twitter"></i>
          </div>
        </a>
        <a class="social social-linkedin" href="https://www.linkedin.com/in/ieva-d-3b4b44113/" target="_blank">
          <div class="front">
            <i class="fa fa-linkedin"></i>
          </div>
          <div class="back">
            <i class="fa fa-linkedin"></i>
          </div>
        </a>
      </div>
    </div>
  </section>
</body>
</html>