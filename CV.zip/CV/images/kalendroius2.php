<?php

define('_DB_HOST', 'localhost');
define('_DB_NAME', 'replace_database_name');
define('_DB_USER', 'replace_username');
define('_DB_PASS', 'replace_password');

?>

<link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/dateTimePicker.css">
    <script type="text/javascript" src="scripts/components/jquery.min.js"></script>
    <script type="text/javascript" src="scripts/dateTimePicker.min.js"></script>

<div id="basic" data-toggle="calendar" ></div>

<script type="text/javascript">
$(document).ready(function()
{
      $('#basic').calendar();
}
</script>

<div id="basic" data-toggle="calendar" data-month="10" data-year="2014" ></div>

<script type="text/javascript">
$(document).ready(function()
{
      $('#basic').calendar({
          day_first: 2
});
}
</script>

<script type="text/javascript">
$(document).ready(function()
{
      $('#basic').calendar({
          day_name: ['CN', 'Hai', 'Ba', 'TÆ°', 'NÄƒm', 'SÃ¡u', 'Báº£y'],
          month_name: ['ThÃ¡ng Má»™t', 'ThÃ¡ng Hai', 'ThÃ¡ng Ba', 'ThÃ¡ng TÆ°', 'ThÃ¡ng NÄƒm', 'ThÃ¡ng SÃ¡u', 'ThÃ¡ng Báº£y', 'ThÃ¡ng TÃ¡m', 'ThÃ¡ng ChÃ­n', 'ThÃ¡ng MÆ°á»i', 'ThÃ¡ng MÆ°á»i Má»™t', 'ThÃ¡ng MÆ°á»i Hai']
        }); 
}
</script>

<script type="text/javascript">
$(document).ready(function()
{
      $('#basic').calendar({
        onSelectDate: function(date, month, year){
          alert([year, month, date].join('-') + ' is: ' + this.isAvailable(date, month, year));
        }
}); 
}
</script>

<script type="text/javascript">
$(document).ready(function()
{
      $('#basic').calendar({
num_next_month: 1,
num_prev_month: 1
}); 
}
</script>

<script type="text/javascript">
$(document).ready(function()
{
      $('#basic').calendar({
unavailable: ['2014-07-10', â€˜2014-07-11â€™]
}); 
}
</script>

<script type="text/javascript">
$(document).ready(function()
{
      $('#basic').calendar({
unavailable: ['*-*-8', '*-*-10']
}); 
}
</script>

<script type="text/javascript">
$(document).ready(function()
{
      $('#basic').calendar({
adapter: 'server/adapter.php'
}); 
}
</script>
