<?php 
session_start();

$db = mysqli_connect('localhost', 'root', 'root', 'CV') or die(mysqli_error($db));

if ("POST" == $_SERVER["REQUEST_METHOD"]) {
  if(isset($_POST["username"]) && isset($_POST["email"]) && isset($_POST["message"])){
    
    if (empty($_POST) == false) {
    $errors = array();
    $username = strip_tags($_POST["username"]);
    $email = strip_tags($_POST["email"]);
    $message = strip_tags($_POST["message"]);

    if (empty($username) == true || empty($email) == true || empty($message) == true) {
      $errors[] = "<p style=\"font-color:white; font-size: 25px;\" align=\"center\">Įveskite vardą, el. paštą ir žinutę!<p>";
    } else {
      if (ctype_alnum($username) == true) {
        $errors[] = "<p style=\"font-color:white; font-size: 25px;\" align=\"center\">Varde galima naudoti tik raides!</p>";
      }
      if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
        $errors[] = "<p style=\"font-color:white; font-size: 25px;\" align=\"center\"> Neteisingas el. pašto adresas!</p>";
      }
    }

    if (empty($errors) == true) {
      mail("drungelike@gmail.com", "Kontaktai", $message, "Nuo:" . $email);
      $_SESSION["msgsent"] = true;
    }

    if (empty($username) == false && empty($email) == false && empty($message) == false && $_SESSION["msgsent"] == true){
      $sql = "INSERT INTO forma(username, email, message)
               VALUES ('{$username}','{$email}','{$message}')";
      mysqli_query($db, $sql) or die(mysqli_error($db));
    }
    }
    mysqli_close($db);
  }

  $_SESSION["errors"] = serialize($errors);

  header("Location: index.php");
  exit;
}
?><!DOCTYPE html>
<html lang="en-US">
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <title>CV</title>

  <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico"/>
  <link rel="stylesheet" type="text/css" media="all" href="style/style.css">
  <link rel="stylesheet" type="text/css" media="all" href="style/responsive.css">

</head>

<body class="home blog dark">
  <div class="switherHead"></div>
  <?php
  if (isset($_SESSION["msgsent"]) == true) {
    echo "<p style=\"font-color:white; font-size: 25px;\" align=\"center\">Žinutė išsiųsta!</p><br>";
    $_SESSION["msgsent"] = false;
  }

  if (isset($_SESSION["errors"])) {
    $errors = unserialize($_SESSION["errors"]);
  }

  if (empty($errors) == false) {
    echo "<ul>";
    foreach ($errors as $error) {
      echo "<li>", $error, "<li>";
    }
    echo "</ul>";
  }
  session_destroy();
  ?>
  <div class="colored">
    <div class="blue"></div>
    <div class="aqua"></div>
    <div class="green"></div>
    <div class="yellow"></div>
    <div class="red"></div>
  </div>

  <!-- APIE MANE -->
  <div class="hfeed site" id="page">
    <div id="main">
      <div class="content_area" id="primary">
        <div role="main" class="site_content" id="content">
          <section class="section profile_section first odd" id="profile">
            <div class="section_header profile_section_header opened">
              <h2 class="section_title profile_section_title vis"><a href="#"><span class="icon icon-user"></span><span class="section_name">Apie mane</span></a><span class="section_icon"></span></h2>
              <div id="profile_header">
                <div id="profile_user">
                  <div id="profile_photo">
                    <img src="images_post/ieva.jpg" alt="Ieva Drungėlaitė"/>
                  </div>
                  <div id="profile_name_area">
                    <div id="profile_name">
                      <h1 id="profile_title"><span class="firstname">Ieva</span> <span class="lastname">Drungėlaitė</span></h1>
                      <h4 id="profile_position">Programuotoja</h4>
                    </div>
                  </div>
                </div>

      <!-- kontakt. duomenys -->
                <div id="profile_data">
                  <div class="profile_row name"><span class="th">Vardas, pavardė:</span><span class="td">Ieva Drungėlaitė</span>
                  </div>
                  <div class="profile_row birth"><span class="th">Gimimo data:</span><span class="td">1990-04-06</span></div>
                  <div class="profile_row phone"><span class="th">Tel. nr.:</span><span class="td">869657344</span>
                  </div>
                  <div class="profile_row email"><span class="th">El. paštas:</span><span class="td">ieva.drung@gmail.com</span>
                  </div>
                </div>
              </div>
            </div>
      <!-- end of kontakt. duomenys -->

            <div class="section_body profile_section_body">
              <div class="proile_body">Esu savarankiška, punktuali, kruopšti, komunikabili, kryptingai siekiu užsibrėžto tikslo. Atsakingai žiūriu į pavestus darbus.
              </div>
            </div>
          </section>
            <div id="mainpage_accordion_area"> 
    <!-- end of APIE MANE --> 

      <!-- RESUME -->
          <section class="section resume_section even" id="resume">
            <div id="resume_buttons">
              <a target="_blank" id="resume_link" href="print.html"><span class="label">Spausdinti</span><span class="icon-print icon"></span></a>
            </div>
            <div class="section_header resume_section_header">
              <h2 class="section_title resume_section_title"><a href="#"><span class="icon icon-align-left"></span><span class="section_name">CV</span></a><span class="section_icon"></span></h2>
            </div>

<!-- Kompiuteriniai įgūdžiai -->
            <div class="section_body resume_section_body">
              <div class="sidebar resume_sidebar">
                <aside class="widget widget_skills">
                  <h3 class="widget_title">Kompiuteriniai įgūdžiai</h3>
                  <div class="widget_inner style_1">
                    <div class="skills_row odd first">
                      <span class="caption">HTML</span><span class="progressbar"><span data-process="80%" class="progress blue"><span class="value">80%</span></span></span>
                    </div>
                    <div class="skills_row even">
                      <span class="caption">CSS</span><span class="progressbar"><span data-process="80%" class="progress green"><span class="value">80%</span></span></span>
                    </div>
                    <div class="skills_row odd">
                      <span class="caption">JavaScript</span><span class="progressbar"><span data-process="20%" class="progress yellow"><span class="value">20%</span></span></span>
                    </div>
                    <div class="skills_row even">
                      <span class="caption">PHP</span><span class="progressbar"><span data-process="50%" class="progress blue"><span class="value">50%</span></span></span>
                    </div>
                    <div class="skills_row odd">
                      <span class="caption">MySQL</span><span class="progressbar"><span data-process="50%" class="progress green"><span class="value">50%</span></span></span>
                    </div>
                    <div class="skills_row even">
                      <span class="caption">WordPress</span><span class="progressbar"><span data-process="20%" class="progress yellow"><span class="value">20%</span></span></span>
                    </div>
                    <div class="skills_row odd"><span class="caption">Adobe Photoshop</span><span class="progressbar"><span data-process="50%" class="progress blue"><span class="value">30%</span></span></span>
                    </div>
                  </aside>
      <!-- Kalbos -->
                <aside class="widget widget_skills">
                  <h3 class="widget_title">Kalbos</h3>
                  <div class="widget_inner style_3">
                    <div class="skills_row odd first">
                      <span class="caption">Lietuvių</span><span class="progressbar"><span data-process="90%" class="progress aqua"></span></span>
                    </div>
                    <div class="skills_row even">
                      <span class="caption">Anglų</span><span class="progressbar"><span data-process="80%" class="progress green"></span></span>
                    </div>
                    <div class="skills_row odd">
                      <span class="caption">Rusų</span><span class="progressbar"><span data-process="40%" class="progress yellow"></span></span>
                    </div>
                  </div>
                </aside>
              </div>

  <!-- Darbo patirtis -->
              <div class="wrapper resume_wrapper">
                <div class="category resume_category resume_category_1 first even">
                  <div class="category_header resume_category_header">
                    <h3 class="category_title"><span class="category_title_icon aqua"></span>Darbo patirtis</h3>
                  </div>
                  <div class="category_body resume_category_body">
                    <article class="post resume_post resume_post_1 first even">
                      <div class="post_header resume_post_header">
                        <div class="resume_period">
                          <span class="period_from">2016</span> - <span class="period_to">2017</span>
                        </div>
                        <h4 class="post_title"><span class="post_title_icon aqua"></span>Klientų aptarnavimo specialistė</h4>
                        <h5 class="post_subtitle">AB „Lietuvos paštas“</h5>
                      </div>
                      <div class="post_body resume_post_body">
                        <p>Siuntų priėmimas, mokesčiai, kreditai, sąskaitų-faktūrų išrašymas.</p>
                      </div>
                    </article>
                    <article class="post resume_post resume_post_2 odd">
                      <div class="post_header resume_post_header">
                        <div class="resume_period"><span class="period_from">2012</span> - <span class="period_to period">2017</span>
                        </div>
                        <h4 class="post_title"><span class="post_title_icon aqua"></span>Vertėja</h4>
                        <h5 class="post_subtitle">Individuali vertimo veikla</h5>
                      </div>
                      <div class="post_body resume_post_body">
                        <p>Verčiau lietuvių-anglų, anglų-lietuvių kalbomis.</p>
                      </div>
                    </article>
                  </div>
                  <!-- .category_body -->
                </div>
                <!-- .category -->

  <!-- Išsilavinimas -->
                <div class="category resume_category resume_category_2 odd">
                  <div class="category_header resume_category_header">
                    <h3 class="category_title"><span class="category_title_icon green"></span>Išsilavinimas</h3>
                  </div>
                  <div class="category_body resume_category_body">
                    <article class="post resume_post resume_post_1 first even">
                      <div class="post_header resume_post_header">
                        <div class="resume_period">
                          <span class="period_from">2017.08.01</span> - <span class="period_to">2017.08.29</span>
                        </div>
                        <h4 class="post_title"><span class="post_title_icon green"></span>Tinklapių kūrimo pradmenys</h4>
                        <h5 class="post_subtitle">Klaipėda Coding School</h5>
                      </div>
                      <div class="post_body resume_post_body">
                        <p>Intensyvus kursas, kurio metu dėstomi HTML, CSS, JavaScript, Jquery, SQL, PHP pagrindai. Kursus finansuoja Lietuvos darbo birža, todėl darbdaviui pusę metų bus suteikiama subsidija.</p>
                      </div>
                    </article>
                    <article class="post resume_post resume_post_2 odd">
                      <div class="post_header resume_post_header">
                        <div class="resume_period">
                          <span class="period_from">2013</span> - <span class="period_to">2015</span>
                        </div>
                        <h4 class="post_title"><span class="post_title_icon green"></span>Techninės kalbos vertimas ir lokalizacija</h4>
                        <h5 class="post_subtitle">Kauno technologijos universitetas</h5>
                      </div>
                      <div class="post_body resume_post_body">
                        <p>Magistro studijos.</p>
                      </div>
                    </article>
                    <article class="post resume_post resume_post_3 even">
                      <div class="post_header resume_post_header">
                        <div class="resume_period">
                          <span class="period_from">2009</span> - <span class="period_to">2013</span>
                        </div>
                        <h4 class="post_title"><span class="post_title_icon green"></span>Anglų kalbos filologija</h4>
                        <h5 class="post_subtitle">Šiaulių universitetas</h5>
                      </div>
                      <div class="post_body resume_post_body">
                        <p>Bakalauro studijos.</p>
                      </div>
                    </article>
                  </div>
                      <!-- /category_body -->
                </div>
                  <!-- /category -->
              </div>
                <!-- /wrapper -->
            </div>
                <!-- /section_body --> 
          </section>
              <!-- end of RESUME--> 


          <!-- PORTFOLIO -->
          <section class="section portfolio_section" id="portfolio">
            <div class="section_header portfolio_section_header">
              <h2 class="section_title portfolio_section_title"><a href="#"><span class="icon icon-briefcase"></span><span class="section_name">Portfolio</span></a><span class="section_icon"></span></h2>
            </div>
            <div class="section_body portfolio_section_body">
              <div class="portfolio_wrapper">
                <div class="portfolio_items">
                  <article class="post portfolio_post">
                    <div class=" post_pic portfolio_post_pic">
                      <div class="port" id="pict">
                        <a href="http://www.hydrostart.lt/" target="_blank"><img src="images/hydrostart.png" alt="hydrostart.lt">
                          <div class="port-s">
                            <h2>HydroStart</h2>
                          </div>
                        </a>
                      </div>
                    </div>
                  </article>
                  <article class="post portfolio_post">
                    <div class=" post_pic portfolio_post_pic">
                      <div class="port" id="pict">
                        <a href="https://github.com/ievadr/Projektas" target="_blank"><img src="images/box.png" alt="github.com/ievadr/Projektas">
                          <div class="port-s">
                            <h2>Projektas</h2>
                          </div>
                        </a>
                      </div>
                    </div>
                  </article>
                </div>
              </div>
            </div>
            <!-- .section_body --> 
          </section>
          <!-- /PORTFOLIO -->

  <!-- CONTACTS -->
        <section class="section contact_section even" id="contact">
          <div class="section_header contact_section_header">
            <h2 class="section_title contact_section_title"><a href="#"><span class="icon icon-envelope-alt"></span><span class="section_name">Kontaktai</span></a><span class="section_icon"></span></h2>
          </div>
          <div class="section_body contact_section_body">
            <div class="sidebar contact_sidebar">
              <aside class="" id="qrcode-vcard-widget-2">
                <div class="">
                </aside>
              </div>
              <div class="contact_form">
                <div class="contact_form_data">
                  <div class="sc_contact_form">
                    <h3 class="title">Susisiekite</h3>
                    <form action="" method="POST">
                      <div class="field">
                        <label class="required" for="sc_contact_form_username">Vardas, pavardė</label>
                        <input type="text" name="username" id="sc_contact_form_username">
                      </div>
                      <div class="field">
                        <label class="required" for="sc_contact_form_email">El. paštas</label>
                        <input type="text" name="email" id="sc_contact_form_email">
                      </div>
                      <div class="field message">
                        <label class="required" for="sc_contact_form_message">Žinutė</label>
                        <textarea name="message" id="sc_contact_form_message"></textarea>
                      </div>
                      <div class="pateikti">
                        <input class="enter" type="submit" name="pateikti">
                      </div>

          
            <!-- end of social icons -->
                    </form><!-- social icons -->
                      <div class="ikonos">
                        <a href="https://www.facebook.com/ieva.drungelaite" target="_blank"><img class="facebook" src="images/icons/facebook.png" onmouseover="this.src='images/icons/Facebook2.png';" onmouseout="this.src='images/icons/facebook.png';" alt="Facebook" width="35"></a>
                        <a href="https://www.linkedin.com/in/ieva-d-3b4b44113/" target="_blank"><img class="linkedin" src="images/icons/linkedin.png" onmouseover="this.src='images/icons/linkedin2.png';" onmouseout="this.src='images/icons/linkedin.png';" alt="Linkedin" width="35"></a>
                        <a href="skype:ieva.drungelaite?chat"><img class="skype" src="images/icons/skype.png" onmouseover="this.src='images/icons/skype2.png';" onmouseout="this.src='images/icons/skype.png';" alt="Skype" width="35"></a>
                        <a href="mailto:ieva.drung@gmail.com" ><img class="mail" src="images/icons/mail.png" onmouseover="this.src='images/icons/email.png';" onmouseout="this.src='images/icons/mail.png';" alt="Mail"  width="35"></a>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          <!-- .section_body --> 
          </section>
        <!-- end of CONTACT --> 
        </div>
      <!-- #mainpage_accordion_area --> 
      </div>
    <!-- #content --> 
    </div>
  <!-- #primary --> 
  </div>
<!-- #main -->
  
  <footer role="contentinfo" class="site_footer" id="footer">
  </footer>
</div>
<!-- #page --> 

<!-- connect js --> 
<script type="text/javascript" src="js/jquery.min.js"></script> 
<script type="text/javascript" src="js/jquery.tools.custom.js"></script> 
<script type="text/javascript" src="js/jquery.flexslider.min.js"></script> 
<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script> 
<script type="text/javascript" src="js/jquery.isotope.min.js"></script> 
<script type="text/javascript" src="js/jquery.cookie.js"></script> 
<script type="text/javascript" src="js/mediaelement.min.js"></script> 
<script type="text/javascript" src="js/jquery.qrcode-0.6.0.min.js"></script> 
<script type="text/javascript" src="js/jquery.easing.js"></script> 
<script type="text/javascript" src="js/jquery.reject.js"></script> 
<script type="text/javascript" src="js/utils.js"></script> 
<script type="text/javascript" src="js/lib.js"></script>
</body>
</html>